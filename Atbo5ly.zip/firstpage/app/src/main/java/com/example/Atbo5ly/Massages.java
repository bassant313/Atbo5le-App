package com.example.Atbo5ly;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Massages extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_massages);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}
